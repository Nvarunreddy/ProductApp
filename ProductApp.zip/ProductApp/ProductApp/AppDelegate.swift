//
//  AppDelegate.swift
//  ProductApp
//
//  Created by Varun
//

import UIKit
import IQKeyboardManagerSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    static let shared = UIApplication.shared.delegate as! AppDelegate

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        self.commonSetup()
        return true
    }

    func commonSetup(){
        IQKeyboardManager.shared.enable = true
        
        if !UserDefaults.standard.bool(forKey: kIsLaunchHistory){
            self.insertDataFirstTime()
        }
        UserDefaults.standard.setValue(true, forKey: kIsLaunchHistory)
    }
    
    func showAlert(_ message:String){
        let alert = UIAlertController(title: "Product App", message: message, preferredStyle: .alert)
        let actionOk = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alert.addAction(actionOk)
        self.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    func insertDataFirstTime(){
        let objProvider = DBHelper.shared.addProvider(name: "Manoj")
        DBHelper.shared.addProvider(name: "Ashish")
        DBHelper.shared.addProvider(name: "Pushpam")
        DBHelper.shared.addProvider(name: "Bharat")
        let productName = "Demo Product"
        let description = "Lorem ipsum dollar is static text used in the industry"
        let price = "250"
        DBHelper.shared.addProduct(name: productName, description: description, price: price, provider: objProvider)
    }


}

