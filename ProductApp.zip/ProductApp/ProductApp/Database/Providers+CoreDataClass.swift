//
//  Providers+CoreDataClass.swift
//  ProductApp
//
//  Created by Varun
//
//

import Foundation
import CoreData

@objc(Providers)
public class Providers: NSManagedObject {

}
