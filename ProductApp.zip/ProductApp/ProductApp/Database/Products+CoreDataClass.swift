//
//  Products+CoreDataClass.swift
//  ProductApp
//
//  Created by Varun
//
//

import Foundation
import CoreData

@objc(Products)
public class Products: NSManagedObject {

}
