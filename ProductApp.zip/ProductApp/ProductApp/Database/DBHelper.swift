//
//  DBHelper.swift
//  ProductApp
//
//  Created by Varun
//

import Foundation
import CoreData


class DBHelper{
    
    static let shared = DBHelper()
    
    // MARK: - Core Data stack

      lazy var persistentContainer: NSPersistentContainer = {
          
          let container = NSPersistentContainer(name: "ProductApp")
          container.loadPersistentStores(completionHandler: { (storeDescription, error) in
              if let error = error as NSError? {
                  fatalError("Unresolved error \(error), \(error.userInfo)")
              }
          })
          return container
      }()
    
    lazy var context = persistentContainer.viewContext

      // MARK: - Core Data Saving support

      func saveContext () {
          let context = persistentContainer.viewContext
          if context.hasChanges {
              do {
                  try context.save()
              } catch {
                  let nserror = error as NSError
                  fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
              }
          }
      }
    
    func isProviderExist(name:String) -> Bool{
        let fetchReq = NSFetchRequest<NSFetchRequestResult>(entityName: "Providers")
        fetchReq.predicate =  NSPredicate(format: "providerName == %@", name)
        do {
            if let projects = try context.fetch(fetchReq) as? [Providers]{
                return projects.count > 0
            }
        }catch{
            print("Error while fetching",error.localizedDescription)
        }
        return false
    }
    
    @discardableResult func addProvider(name:String) -> Providers{
        let provider = Providers(context: self.context)
        provider.providerName = name
        self.saveContext()
        return provider
    }
    
    
    func getAllProviders() -> [Providers]{
        let fetchReq = NSFetchRequest<NSFetchRequestResult>(entityName: "Providers")
        do {
            if let projects = try context.fetch(fetchReq) as? [Providers]{
                return projects
            }
        }catch{
            print("Error while fetching",error.localizedDescription)
        }
        return []
    }
    
    @discardableResult func addProduct(name:String,description:String,price:String,provider:Providers) -> Products{
        let product = Products(context: self.context)
        product.productName = name
        product.price = price
        product.productDescription = description
        product.provider = provider
        self.saveContext()
        return product
    }
    
    func getProductList() -> [Products]{
        let fetchReq = NSFetchRequest<NSFetchRequestResult>(entityName: "Products")
        do {
            if let projects = try context.fetch(fetchReq) as? [Products]{
                return projects
            }
        }catch{
            print("Error while fetching",error.localizedDescription)
        }
        return []
    }
    
}
