//
//  Products+CoreDataProperties.swift
//  ProductApp
//
//  Created by Varun
//
//

import Foundation
import CoreData


extension Products {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Products> {
        return NSFetchRequest<Products>(entityName: "Products")
    }

    @NSManaged public var productName: String?
    @NSManaged public var price: String?
    @NSManaged public var productDescription: String?
    @NSManaged public var provider: Providers?

}

extension Products : Identifiable {

}
