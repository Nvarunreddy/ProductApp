//
//  ProductsOfProvider.swift
//  ProductApp
//
//  Created by Varun
//

import UIKit

class ProductsOfProvider: UIViewController,UITableViewDataSource,UITableViewDelegate {

    //MARK:- Outlets
    @IBOutlet weak var tblView : UITableView!
    
    //MARK:- Class Variables
    var provider : Providers!
    var arrProuducts : [Products] = []
    
    //MARK:- Custom Methods
    
    func setUp(){
        self.tblView.register(UINib(nibName: "ProductCell", bundle: nil), forCellReuseIdentifier: "ProductCell")
        //
        self.arrProuducts = (self.provider.products?.allObjects as? [Products]) ?? []
        self.tblView.dataSource = self
        self.tblView.delegate = self
        self.tblView.rowHeight = UITableView.automaticDimension
        self.tblView.estimatedRowHeight = 150
        self.tblView.separatorStyle = .none
    }
    
    
    
    //MARK:- Action Methods
    
    @IBAction func backTapped(_ sender : UIButton){
         _ = self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- Table View delegates & Datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrProuducts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let productCell = tableView.dequeueReusableCell(withIdentifier: "ProductCell") as! ProductCell
        productCell.productData = self.arrProuducts[indexPath.row]
        productCell.vwButtons.isHidden = true
        return productCell
    }
    
    //MARK:- View Controller Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }
}
