//
//  ListViewController.swift
//  ProductApp
//
//  Created by Varun
//

import UIKit

class ListViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    //MARK:- Outlets    
    @IBOutlet weak var tableView : UITableView!
    @IBOutlet weak var txtSearch : UITextField!
    @IBOutlet weak var productButton : UIButton!
    @IBOutlet weak var providerButton : UIButton!
    @IBOutlet weak var addButton : UIButton!
    
    //MARK:- Class Variables
    var arrProducts : [Products] = []
    var arrProviders : [Providers] = []
    var arrSearchProducts : [Products] = []
    var isProduct = true
    var isSearch : Bool{
        return self.txtSearch.text != ""
    }
    var blueColor : UIColor!
    let offWhiteColor = UIColor.white.withAlphaComponent(0.7)
    
    //MARK:- Custom Methods
    
    func setUI(){
        self.blueColor = self.productButton.backgroundColor
        //
        txtSearch.attributedPlaceholder = NSAttributedString(string: "Search...", attributes: [.foregroundColor:UIColor.white.withAlphaComponent(0.7)])
        //
        self.tableView.register(UINib(nibName: "ProductCell", bundle: nil), forCellReuseIdentifier: "ProductCell")
        self.tableView.register(UINib(nibName: "ProviderCell", bundle: nil), forCellReuseIdentifier: "ProviderCell")
        //
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.rowHeight = UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 150
        self.tableView.separatorStyle = .none
        //
        self.txtSearch.addTarget(self, action: #selector(searchProduct), for: .editingChanged)
        
        self.productButton.layer.borderWidth = 1.0
        self.providerButton.layer.borderWidth = 1.0
        
        self.productButton.sendActions(for: .touchUpInside)
        
        self.addButton.layer.cornerRadius = self.addButton.bounds.width / 2.0
    }
    
    @objc func searchProduct(){
        if self.txtSearch.text != ""{
            self.arrSearchProducts = self.arrProducts.filter({ (product) -> Bool in
                (product.productName ?? "").localizedCaseInsensitiveContains(self.txtSearch.text ?? "") || (product.productDescription ?? "").localizedCaseInsensitiveContains(self.txtSearch.text ?? "")
            })
        }
        self.tableView.reloadData()
    }
    
    //MARK:- Click Events
    
    @IBAction func productTapped(_ sender : UIButton){
        sender.setTitleColor(.white, for: .normal)
        sender.backgroundColor = self.blueColor
        sender.layer.borderColor = UIColor.clear.cgColor
        
        providerButton.setTitleColor(blueColor, for: .normal)
        providerButton.backgroundColor = .clear
        providerButton.layer.borderColor = self.offWhiteColor.cgColor
        self.txtSearch.isHidden = false
        
        self.isProduct = true
        self.tableView.reloadData()
    }
    
    @IBAction func providerTapped(_ sender : UIButton){
        sender.setTitleColor(.white, for: .normal)
        sender.backgroundColor = self.blueColor
        sender.layer.borderColor = UIColor.clear.cgColor
        
        productButton.setTitleColor(blueColor, for: .normal)
        productButton.backgroundColor = .clear
        productButton.layer.borderColor = self.offWhiteColor.cgColor
        self.txtSearch.isHidden = true
        self.txtSearch.text = ""
        
        self.isProduct = false
        self.tableView.reloadData()
    }
    
    @IBAction func addTapped(_ sender : UIButton){
        let objVC = self.storyboard?.instantiateViewController(withIdentifier: "AddNewProduct" ) as! AddNewProduct
        self.navigationController?.pushViewController(objVC, animated: true)
    }
    
    //MARK:- Delegates
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isProduct{
            return isSearch ? self.arrSearchProducts.count : self.arrProducts.count
        }
        return self.arrProviders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if self.isProduct{
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell") as! ProductCell
            cell.productData = isSearch ? self.arrSearchProducts[indexPath.row] : self.arrProducts[indexPath.row]
            cell.actionDelete = {
                let product = self.isSearch ? self.arrSearchProducts[indexPath.row] : self.arrProducts[indexPath.row]
                DBHelper.shared.context.delete(product)
                DBHelper.shared.saveContext()
                
                if self.isSearch{
                    self.arrSearchProducts.remove(at: indexPath.row)
                    tableView.reloadData()
                    self.arrProducts = DBHelper.shared.getProductList()
                }else{
                    self.arrProducts.remove(at: indexPath.row)
                    tableView.reloadData()
                }
            }
            
            cell.actionUpdate = {
                let obj = self.storyboard?.instantiateViewController(withIdentifier: "AddNewProduct") as! AddNewProduct
                obj.isEdit = true
                obj.productData = self.isSearch ? self.arrSearchProducts[indexPath.row] : self.arrProducts[indexPath.row]
                self.navigationController?.pushViewController(obj, animated: true)
            }
            
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProviderCell") as! ProviderCell
        cell.providerData = self.arrProviders[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if !isProduct{
            let objVC = self.storyboard?.instantiateViewController(withIdentifier: "ProductsOfProvider" ) as! ProductsOfProvider
            objVC.provider = self.arrProviders[indexPath.row]
            self.navigationController?.pushViewController(objVC, animated: true)
        }        
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.arrProducts = DBHelper.shared.getProductList()
        self.arrProviders = DBHelper.shared.getAllProviders()
        self.tableView.reloadData()
    }

}


