//
//  ProviderAddViewController.swift
//  ProductApp
//
//  Created by Varun
//

import UIKit

class ProviderAddViewController: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var providerNameTextfield : ThemeTextField!
    
    //MARK:- Class Variables
    
    //MARK:- Custom Methods
    
    func setUp(){
        providerNameTextfield.placeholder = "Enter provider name"
        self.providerNameTextfield.textAlignment = .center
    }
    
    //MARK:- Click Events
    
    @IBAction func addTapped(_ sender : UIButton){
        if providerNameTextfield.text == ""{
            AppDelegate.shared.showAlert(Messages.providerName.message)
        }else if DBHelper.shared.isProviderExist(name: self.providerNameTextfield.text!){
            AppDelegate.shared.showAlert(Messages.providerExist.message)
        }else{
            DBHelper.shared.addProvider(name: self.providerNameTextfield.text!)
            _ = self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func backTapped(_ sender : UIButton){
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }

}
