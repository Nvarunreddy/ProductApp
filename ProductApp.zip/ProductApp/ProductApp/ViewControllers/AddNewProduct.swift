//
//  AddNewProduct.swift
//  ProductApp
//
//  Created by Varun
//

import UIKit
import IQKeyboardManagerSwift

class AddNewProduct: UIViewController,UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewAccessibilityDelegate {

    //MARK:- Outlets
    @IBOutlet weak var nameTextfield : ThemeTextField!
    @IBOutlet weak var priceTextField : ThemeTextField!
    @IBOutlet weak var providerTextfield : ThemeTextField!
    @IBOutlet weak var descriptionTextView : IQTextView!
    @IBOutlet weak var addButton : UIButton!
    
    //MARK:- Class Variables
    var isEdit = false
    var providerPicker = UIPickerView()
    var providerList : [Providers]  = []
    var currentProvider : Providers!
    var productData : Products!
    
    //MARK:- Custom Methods
    
    func setUp(){
        //
        self.nameTextfield.placeholder = "Enter Name"
        self.priceTextField.placeholder = "Enter Price"
        self.priceTextField.keyboardType = .decimalPad
        self.providerTextfield.placeholder = "Select Provider"
        self.descriptionTextView.placeholder = "Enter Description"
        //
        self.providerTextfield.delegate = self
        self.providerTextfield.inputView = self.providerPicker
        self.providerPicker.dataSource = self
        self.providerPicker.delegate = self
        
        self.descriptionTextView.layer.borderColor = UIColor.white.cgColor
        self.descriptionTextView.layer.borderWidth = 0.5
        
        if isEdit{
            self.addButton.setTitle("Update", for: .normal)
            self.nameTextfield.text = productData.productName
            self.priceTextField.text = productData.price
            self.providerTextfield.text = productData.provider?.providerName
            self.currentProvider = productData.provider
            self.descriptionTextView.text  = productData.productDescription
        }
    }
    
    func validateView() -> Bool{
        if nameTextfield.text == ""{
            AppDelegate.shared.showAlert(Messages.name.message)
            return false
        }else if priceTextField.text == ""{
            AppDelegate.shared.showAlert(Messages.price.message)
            return false
        }else if providerTextfield.text == ""{
            AppDelegate.shared.showAlert(Messages.provider.message)
            return false
        }else if descriptionTextView.text == ""{
            AppDelegate.shared.showAlert(Messages.desc.message)
            return false
        }
        return true
    }
    
    //MARK:- Textfield delegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == providerTextfield && textField.text == ""{
            self.currentProvider = self.providerList.first
            textField.text = self.providerList.first?.providerName
        }
    }
    
    
    //MARK:- PickerView delegate
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.providerList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.providerList[row].providerName
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let provider = self.providerList[row]
        self.currentProvider = provider
        self.providerTextfield.text = provider.providerName
        
    }
    
    //MARK:- Click Events
    
    @IBAction func addTapped(_ sender : UIButton){
        if self.validateView(){
            if isEdit{
                self.productData.productName = self.nameTextfield.text
                self.productData.provider = self.currentProvider
                self.productData.price = self.priceTextField.text
                self.productData.productDescription = self.descriptionTextView.text
                DBHelper.shared.saveContext()
            }else{
                DBHelper.shared.addProduct(name: self.nameTextfield.text!, description: self.descriptionTextView.text!, price: self.priceTextField.text!, provider: self.currentProvider)
            }
            _ = self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func backTapped(_ sender : UIButton){
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func addProviderTapped(_ sender : UIButton){
        self.view.endEditing(true)
        let objVC = self.storyboard?.instantiateViewController(withIdentifier: "ProviderAddViewController") as! ProviderAddViewController
        self.navigationController?.pushViewController(objVC, animated: true)
    }
    
    //MARK:- Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUp()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.providerList = DBHelper.shared.getAllProviders()
    }

}
