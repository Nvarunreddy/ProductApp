//
//  ProviderCell.swift
//  ProductApp
//
//  Created by Varun
//

import UIKit

typealias EmptyCompletion = () -> ()

class ProductCell: UITableViewCell {
    
    @IBOutlet weak var labelName : UILabel!
    @IBOutlet weak var labelProvider : UILabel!
    @IBOutlet weak var lablePrice : UILabel!
    @IBOutlet weak var labelDesc : UILabel!
    @IBOutlet weak var vwButtons : UIStackView!
    
    var actionDelete : EmptyCompletion?
    var actionUpdate : EmptyCompletion?
    
    var productData : Products!{
        didSet{
            self.setData()
        }
    }

    func setData(){
        self.labelName.text = self.productData.productName
        self.labelProvider.text = "By \(self.productData.provider?.providerName ?? "")"
        self.lablePrice.text = "Only $\(self.productData.price ?? "")"
        self.labelDesc.text = self.productData.productDescription
    }
    
    @IBAction func deleteClicked(_ sender : UIButton){
        actionDelete?()
    }
    
    @IBAction func updateClicked(_ sender : UIButton){
        actionUpdate?()
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.labelDesc.numberOfLines = 0
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
