//
//  ProductCell.swift
//  ProductApp
//
//  Created by Varun
//

import UIKit

class ProviderCell: UITableViewCell {

    @IBOutlet weak var labelName : UILabel!
    @IBOutlet weak var labelProducts : UILabel!
    
    var providerData : Providers!{
        didSet{
            self.setData()
        }
    }
    
    func setData(){
        self.labelName.text = self.providerData.providerName
        if let products = providerData.products?.allObjects as? [Products]{
            let productList = products.compactMap({$0.productName})
            self.labelProducts.text = productList.joined(separator: ", ")
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
