//
//  AppConstants.swift
//  ProductApp
//
//  Created by Varun
//

import Foundation


enum Messages : String{
    case name = "Please enter product name"
    case price = "Please enter product price"
    case provider = "Please select provider"
    case providerName = "Please enter provider name"
    case providerExist = "Provider already exists"
    case desc = "Please enter description"
    
    var message : String{
        return self.rawValue
    }
}


let kIsLaunchHistory = "IsLaunchHistory"
