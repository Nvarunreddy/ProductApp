//
//  GlobalClasses.swift
//  ProductApp
//
//  Created by Varun
//

import Foundation
import UIKit


class ThemeTextField : UITextField{
    
    override var placeholder: String?{
        didSet{
            self.attributedPlaceholder = NSAttributedString(string: self.placeholder ?? "", attributes: [.foregroundColor:UIColor.white.withAlphaComponent(0.7)])
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.textColor = .white
        self.borderStyle = .none
        self.layer.borderColor = UIColor.white.cgColor
        self.layer.borderWidth = 0.5
    }
    
}
